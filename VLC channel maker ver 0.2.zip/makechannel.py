#############################################################################
# makechannel.py v0.02
# by Jason D. Ozubko, 2012,2018 (jdozubko@gmail.com)
#############################################################################
# This file builds a database of media files for use with channelwatch.lua to
# simulate an ongoing television station in VLC.
#
# To use this file, edit the search_path below then execute this file using 
# python. The script will then search through the search_path and all 
# subfolders for any valid video files (currently avi, mpeg/mpg, asf/wmv/wma, 
# mp4/mov/3gp, ogg/ogm, and mkv).
#
# Both filenames and video length will be extracted for each file and saved to
# a file called "new.channel".  [Note that to extract video file length, this
# script depends on an external program, "ffprobe"].  Playing the new.channel
# file in VLC media player (with the watchchannel.lua script installed) will
# execute this new channel.  You may rename the new.channel file to anything you
# like, save it anywhere you like, and edit it to remove or add any files you
# like.
#
# To edit the type of file that this script looks for edit the line below that
# starts off as:
#
# if name.lower().endswith(".avi") or name.lower().endswith(".mpg")...
#
# Note that if you change this line to be audio files (e.g., mp3, wav, etc.)
# then the script will create a new custom radio station channel.
#
# Happy TV viewing/radio listening!!!
#
#
#############################################################################


################################# SETUP #####################################

#change the search_path to be the location of your media files
search_path  = 'c:\\media\\videos\\'

#default output file for your new channel
channel_name = 'new.channel'

########### basic users do not need to edit past this point #################
#
#
#
#
#
#
#
#
#
#
#
#
#
#
#
#
#
#
#
#
#
#
#############################################################################

import os
import subprocess

# open the new.channel file to output things to
f  = open(channel_name, 'w')
df = open('log.txt', 'w')

# channel is 0 by default
f.write("0\n")

#function... returns the duration HH:MM:SS of a video file
def getLength(filename):
  #uses ffprobe to get info about the video file
  result = subprocess.Popen(["ffprobe", filename],
    stdout = subprocess.PIPE, stderr = subprocess.STDOUT)

  #finds the info that has the word "Duration"
  y = [x for x in result.stdout.readlines() if "Duration: " in x]

  #get the location of the "Duration: " phrase
  loc = y[0].find("Duration: ")

  #assuming we find the location of that phrase..
  if loc <> -1:
	#cut out everything before and everything more than 10 characters later
	return y[0][loc+10:loc+18]
  else:
	#if we don't find anything then set it to be 2 seconds of nothing...
	return '00:00:02'


#main code... walk through the subfolders looking for movie files
i = 0
print 'searching ' + search_path + ' for media files...\n'

#
for dirpath, dirnames, files in os.walk(search_path):
	for name in files:
		#debug
#############################################################################
# EDIT THE LINE BELOW TO CHANGE THE TYPE OF MEDIA FILES YOU WANT TO FIND
#############################################################################
		if name.lower().endswith(".avi") or name.lower().endswith(".mpg") or name.lower().endswith(".mpeg") or name.lower().endswith(".asf") or name.lower().endswith(".wmv") or name.lower().endswith(".wma") or name.lower().endswith(".mp4") or name.lower().endswith(".mov") or name.lower().endswith(".3gp") or name.lower().endswith(".ogg") or name.lower().endswith(".ogm") or name.lower().endswith(".mkv"):
			fn = os.path.join(dirpath, name)
			#print fn
			try:
				#figure out the full name, output it, then save it
				#fn_full = os.environ["PWD"] + fn[1:]
				fn_full = fn
				print fn_full
				
				#figure out the length, output it, then save it
				fn_len  = getLength(fn_full)
				print fn_len

				#write the file name and the output
				f.write("%s\n" % fn_full)
				f.write("%s\n" % fn_len)
				print 'added!\n'
				i = i + 1

			except:
				print 'error (with getLength()?)\n'
				
				pass # ignore errors

		else:
			df.write('<SKIPPING> ' + os.path.join(dirpath, name) + '\n')
'''	
			i = i + 1
			if(i > 10):break
	if(i > 10):break
'''

#user output
print '' + str(i) + ' files found\n'

#close the file
f.close()
df.close()
