# aaa_vlc
My VLC plugins for playing music directly off of websites

## Plugins list
### aaasoundcloud_api
This is required for all aaasoundcloud plugins due to the API changes to Soundcloud making it very tedious to be able to keep things under a single plugin file.

### aaasoundcloud
This is for enabling Soundcloud set playback.

### aaasoundcloud_single
This is for enabling playback of single Soundcloud tracks.

### aaasoundcloud_auser
A somewhat useless plugin for playing all tracks an user has posted. Contrary to the original version, this new version can play all of the tracks an user has due to Soundcloud implementing infinite scrolling on the user page.

### bandcamp
The plugin which can play albums and tracks from Bandcamp.

