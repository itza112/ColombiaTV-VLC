# ColombiaTV-VLC
Addon for VLC to watch Colombian TV Channels. The streaming links are public and I don't generate this.

How to Install
==============

1. Copy the colombiatv.lua in the share/lua/sd directory. 

* In Linux like-system the directory for all users is /usr/share/vlc/lua/extensions/
* In Windows the directory for all users is %ProgramFiles%\VideoLAN\VLC\lua\extensions\
* In Mac OS X the directory is /Applications/VLC.app/Contents/MacOS/share/lua/extensions/

4. Start your VLC 

5. On the left panel named Internet, please click on ColombiaTV

6. Enjoy!

Version 1.0
===========
* Initial version
* Include all TV channels. Wish discard TV channels only compatible with Kodi
